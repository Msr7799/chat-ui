<script lang="ts">
	interface Props {
		classNames?: string;
	}

	let { classNames = "" }: Props = $props();
</script>

<svg
	width="1em"
	height="1em"
	viewBox="0 0 24 24"
	xmlns="http://www.w3.org/2000/svg"
	class={classNames}
>
	<defs>
		<style>
			.cls-1 {
				fill: #669df6;
			}
			.cls-2 {
				fill: #aecbfa;
			}
			.cls-3 {
				fill: #4285f4;
			}
		</style>
	</defs>

	<g data-name="Product Icons">
		<polygon
			class="cls-1"
			points="15 10.32 15.16 10.32 15.16 10.16 15.16 9.49 15.16 9.32 15 9.32 12.5 9.32 12.5 8.34 12.5 8.18 12.34 8.18 11.56 8.18 11.4 8.18 11.4 8.34 11.4 9.32 8.99 9.32 8.82 9.32 8.82 9.49 8.82 10.16 8.82 10.32 8.99 10.32 15 10.32"
		/>

		<path
			class="cls-2"
			d="M15.33,14.75a6.8,6.8,0,0,1-2.53-1.27A6.41,6.41,0,0,0,14,11.41H12.81A5,5,0,0,1,12,12.72a4.82,4.82,0,0,1-.81-1.31H10a8.39,8.39,0,0,0,1.27,2.08,6.62,6.62,0,0,1-2.6,1.38l.6,1A8.35,8.35,0,0,0,12,14.27a6.69,6.69,0,0,0,2.75,1.53Z"
		/>

		<path class="cls-3" d="M6.82,19.46l.95,1.65h9.49L22,12.89,20.1,9.6l-4.74,8.21H7.77Z" />

		<path class="cls-3" d="M17.18,4.54l-.95-1.65H6.74L2,11.11,3.9,14.4,8.64,6.19h7.59Z" />
	</g>
</svg>
