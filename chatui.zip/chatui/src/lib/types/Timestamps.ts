export interface Timestamps {
	createdAt: Date;
	updatedAt: Date;
}
